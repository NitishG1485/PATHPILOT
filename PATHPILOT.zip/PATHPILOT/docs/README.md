# PATH PILOT - Gamified Career Guidance Platform

## 🎮 Project Overview

PATH PILOT is a comprehensive gamified career guidance web application that transforms traditional career counseling into an engaging, adventure-themed journey. Users progress through 5 distinct levels of career development, from academic stream selection to landing their dream job.

## 🚀 Quick Start Guide

### Prerequisites

- Python 3.8 or higher
- Web browser (Chrome, Firefox, Safari, Edge)

### Installation & Setup

1. **Extract the project files**
   ```bash
   unzip path-pilot-project.zip
   cd path-pilot-project
   ```

2. **Set up Python environment**
   ```bash
   cd backend
   python3 -m venv venv

   # Activate virtual environment
   # On Windows:
   venv\Scripts\activate
   # On Mac/Linux:
   source venv/bin/activate
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

4. **Run the application**
   ```bash
   python app.py
   ```

5. **Access the application**
   Open your browser and navigate to: `http://localhost:5000`

## 🎯 Features

### 5 Career Guidance Levels
1. **Stream Selection Grove** - Choose academic path (Science/Commerce/Arts)
2. **Skill Discovery Forest** - Skills assessment and personality evaluation
3. **College Selection Meadow** - College and course selection guidance
4. **Internship Valley** - Internship search and application strategies
5. **Career Summit** - Job search techniques and career planning

### Gamification Elements
- XP points system with rewards
- Achievement badges for milestones
- Progress tracking and visualization
- Interactive assessments and quizzes
- Certificate generation upon completion

### Technical Features
- Responsive design (works on all devices)
- User authentication and session management
- Progress saving across browser sessions
- Beautiful animations and particle effects
- Professional certificate generation

## 📁 Project Structure

```
path-pilot-project/
├── backend/
│   ├── app.py                    # Main Flask application
│   ├── requirements.txt          # Python dependencies
│   ├── config.py                 # Configuration settings
│   ├── models/                   # Database models
│   ├── routes/                   # API routes
│   ├── static/                   # Frontend assets
│   └── templates/                # HTML templates
├── frontend/                     # Frontend backup files
├── database/                     # SQLite database (auto-generated)
├── docs/                         # Documentation
└── scripts/                      # Utility scripts
```

## 🛠️ Development

### Making Changes

**Backend Changes:**
- Edit Python files in `backend/`
- Restart the Flask server
- Test API endpoints

**Frontend Changes:**
- Edit files in `backend/static/` and `backend/templates/`
- Refresh browser to see changes

### Database

- SQLite database is automatically created on first run
- Tables: users, user_progress, achievements
- Database file: `database/pathpilot.db`

### API Endpoints

- `POST /api/register` - User registration
- `POST /api/login` - User login
- `GET /api/progress` - Get user progress
- `POST /api/progress` - Update progress
- `POST /api/certificate` - Generate certificate

## 🎨 Customization

### Visual Theme
Edit CSS variables in `backend/static/style.css`:
```css
:root {
    --primary-green: #2d7a32;
    --accent-gold: #ffd700;
    /* ... other variables */
}
```

### Game Content
Modify level data in `backend/static/app.js`:
```javascript
this.levels = [
    // Add or modify level content
];
```

## 🚨 Troubleshooting

**Common Issues:**

1. **"Module not found" errors:**
   ```bash
   pip install -r requirements.txt
   ```

2. **Database errors:**
   ```bash
   rm database/pathpilot.db
   python app.py  # Will recreate database
   ```

3. **Port already in use:**
   - Change port in `app.py`: `app.run(port=5001)`
   - Or kill the process using port 5000

4. **Static files not loading:**
   - Ensure files are in `backend/static/` directory
   - Check file paths in HTML templates

## 🌟 Success Indicators

You'll know everything is working when:
- ✅ Landing page loads with particle animations
- ✅ User registration and login work
- ✅ Dashboard shows progress statistics
- ✅ All 5 levels are accessible and functional
- ✅ Progress saves between sessions
- ✅ Certificate generates after completion

## 📱 Device Compatibility

- **Desktop:** Full experience with all features
- **Tablet:** Touch-optimized interface
- **Mobile:** Responsive design with mobile-first approach

## 🎉 Getting Started

1. Start the application using the instructions above
2. Create a user account on the landing page
3. Explore the beautiful dashboard interface
4. Progress through all 5 career guidance levels
5. Earn XP points and unlock achievements
6. Generate your completion certificate
7. Share your PATH PILOT success!

## 📞 Support

If you encounter any issues:
1. Check the troubleshooting section above
2. Ensure all prerequisites are installed
3. Verify the Flask server is running
4. Check browser console for JavaScript errors

## 🏆 Achievement System

- **Stream Explorer** - Complete Level 1
- **Self Aware** - Complete skill assessment
- **College Ready** - Research college options
- **Intern Hunter** - Master internship strategies
- **Career Champion** - Complete all 5 levels

## 🎓 Educational Value

PATH PILOT provides real career guidance through:
- Indian education system guidance (CBSE streams)
- Professional assessment methodologies
- College selection strategies
- Industry internship insights
- Job market preparation techniques

---

**Developed with ❤️ for career success**

*Transform your career journey into an epic adventure with PATH PILOT!*
