# PATH PILOT - Complete Setup Guide

## 🎯 Overview

This guide will walk you through setting up and running the complete PATH PILOT project.

## 📋 Prerequisites

Before starting, ensure you have:

- **Python 3.8+** installed on your system
- **Web browser** (Chrome, Firefox, Safari, or Edge)
- **Command line** access (Terminal/Command Prompt)
- **Internet connection** for downloading dependencies

## 🚀 Step-by-Step Setup

### Step 1: Extract Project Files

1. Download and extract `path-pilot-project.zip`
2. Open command line/terminal
3. Navigate to the extracted directory:
   ```bash
   cd path-pilot-project
   ```

### Step 2: Backend Setup

1. **Navigate to backend directory:**
   ```bash
   cd backend
   ```

2. **Create virtual environment:**
   ```bash
   python3 -m venv venv
   ```

   Or on Windows:
   ```bash
   python -m venv venv
   ```

3. **Activate virtual environment:**

   **On Windows:**
   ```bash
   venv\Scripts\activate
   ```

   **On Mac/Linux:**
   ```bash
   source venv/bin/activate
   ```

4. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

### Step 3: Run the Application

1. **Start the Flask server:**
   ```bash
   python app.py
   ```

2. **Verify startup:**
   You should see output similar to:
   ```
   * Running on http://127.0.0.1:5000
   * Debug mode: on
   ```

3. **Access the application:**
   Open your web browser and go to:
   ```
   http://localhost:5000
   ```

## ✅ Verification Checklist

Confirm everything is working:

- [ ] Landing page loads with animated background
- [ ] Particle effects are visible
- [ ] Navigation buttons respond to clicks
- [ ] User registration works
- [ ] Login functionality works
- [ ] Dashboard displays correctly
- [ ] All 5 levels are accessible
- [ ] Progress tracking functions
- [ ] Certificate generation works

## 🛠️ Alternative Setup Methods

### Method 1: Using Scripts (if available)

**Windows:**
```bash
cd scripts
run.bat
```

**Mac/Linux:**
```bash
cd scripts
chmod +x run.sh
./run.sh
```

### Method 2: Manual Configuration

If automated setup fails:

1. **Check Python version:**
   ```bash
   python --version
   ```

2. **Install Flask manually:**
   ```bash
   pip install Flask Flask-CORS
   ```

3. **Create database directory:**
   ```bash
   mkdir -p ../database
   ```

4. **Run application:**
   ```bash
   python app.py
   ```

## 📁 File Structure Verification

Ensure your project has this structure:

```
path-pilot-project/
├── backend/
│   ├── app.py                    ✅ Main application
│   ├── requirements.txt          ✅ Dependencies
│   ├── config.py                 ✅ Configuration
│   ├── models/                   ✅ Database models
│   ├── routes/                   ✅ API routes
│   ├── static/                   ✅ Frontend files
│   │   ├── style.css
│   │   └── app.js
│   └── templates/                ✅ HTML templates
│       └── index.html
├── database/                     ✅ Database files (auto-created)
├── docs/                         ✅ Documentation
└── frontend/                     ✅ Backup files
```

## 🔧 Configuration Options

### Port Configuration
To change the default port (5000):

1. Edit `backend/app.py`
2. Find the last line: `app.run(debug=True, host='0.0.0.0', port=5000)`
3. Change `port=5000` to your preferred port
4. Restart the application

### Database Configuration
- Default: SQLite database in `database/pathpilot.db`
- Tables are automatically created on first run
- To reset database: delete the `.db` file and restart

### Secret Key
For production, update the secret key in `backend/app.py`:
```python
app.secret_key = 'your-secure-secret-key-here'
```

## 🚨 Troubleshooting

### Common Issues and Solutions

**1. Python not found**
```bash
# Try these alternatives:
python3 --version
py --version
python --version
```

**2. Permission denied (Mac/Linux)**
```bash
sudo python3 -m pip install -r requirements.txt
```

**3. Port already in use**
```bash
# Kill process on port 5000 (Mac/Linux):
lsof -ti:5000 | xargs kill -9

# Windows:
netstat -ano | findstr :5000
taskkill /PID <PID_NUMBER> /F
```

**4. Module import errors**
```bash
# Ensure virtual environment is activated
# Check if in correct directory
pwd  # Should show path ending in /backend
```

**5. Database errors**
```bash
# Delete and recreate database
rm ../database/pathpilot.db
python app.py
```

**6. Frontend not loading**
- Check if files exist in `backend/static/` and `backend/templates/`
- Verify browser cache (try incognito/private mode)
- Check browser console for errors (F12)

### Error Messages and Solutions

**"Template not found"**
- Ensure `index.html` exists in `backend/templates/`

**"Static file not found"**
- Verify `style.css` and `app.js` are in `backend/static/`

**"Connection refused"**
- Confirm Flask server is running
- Check correct port (default: 5000)

**"Internal Server Error"**
- Check Flask console for error details
- Verify database permissions

## 🌟 Feature Testing

After setup, test these features:

### Basic Functionality
1. **Landing Page**
   - Animated background
   - Navigation buttons
   - Level preview cards

2. **Authentication**
   - User registration
   - Login/logout
   - Session persistence

3. **Game Features**
   - Dashboard statistics
   - Level progression
   - XP and achievement system
   - Progress saving

### Advanced Features
1. **Level Content**
   - Stream selection interface
   - Skill assessments
   - College guidance tools
   - Internship resources
   - Career planning content

2. **Certificate System**
   - Completion tracking
   - Certificate generation
   - Download functionality

## 📱 Device Testing

Test on multiple devices/browsers:

- **Desktop browsers:** Chrome, Firefox, Safari, Edge
- **Mobile devices:** iOS Safari, Android Chrome
- **Tablet devices:** iPad, Android tablets

## 🎯 Performance Optimization

For better performance:

1. **Clear browser cache** regularly during development
2. **Use latest browser versions**
3. **Ensure stable internet connection** for font loading
4. **Close unnecessary browser tabs**

## 🔄 Development Workflow

For ongoing development:

1. **Make changes** to backend files
2. **Save files**
3. **Restart Flask server** (Ctrl+C, then `python app.py`)
4. **Refresh browser** to see changes

For frontend changes:
1. **Edit files** in `backend/static/` or `backend/templates/`
2. **Refresh browser** (changes are immediate)

## 🎉 Success!

Once everything is working, you should see:

- 🌟 Beautiful animated landing page
- 🎮 Functional user registration and login
- 📊 Interactive dashboard with progress tracking
- 🏞️ All 5 career guidance levels accessible
- 🏆 Achievement system working
- 📜 Certificate generation functional

**You're now ready to embark on your PATH PILOT adventure!**

---

*If you encounter issues not covered here, check the main README.md file or review the Flask server console output for specific error messages.*
