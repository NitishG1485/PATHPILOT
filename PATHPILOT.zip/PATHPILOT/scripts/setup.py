#!/usr/bin/env python3
"""
PATH PILOT - Automated Setup Script
This script sets up the complete PATH PILOT project environment.
"""

import os
import sys
import subprocess
import shutil
from pathlib import Path

def print_header():
    print("=" * 60)
    print("🎮 PATH PILOT - Automated Setup Script")
    print("🚀 Gamified Career Guidance Platform")
    print("=" * 60)

def check_python_version():
    """Check if Python version is 3.8 or higher"""
    if sys.version_info < (3, 8):
        print("❌ Python 3.8 or higher is required!")
        print(f"   Current version: {sys.version}")
        print("   Please download Python from: https://www.python.org/downloads/")
        sys.exit(1)
    print(f"✅ Python {sys.version_info.major}.{sys.version_info.minor} detected")

def setup_virtual_environment():
    """Create and setup Python virtual environment"""
    print("\n🔧 Setting up virtual environment...")

    venv_path = Path("backend/venv")
    if venv_path.exists():
        print("  ⚠️  Virtual environment already exists")
        return True

    try:
        os.chdir("backend")
        subprocess.run([sys.executable, "-m", "venv", "venv"], check=True)
        print("  ✅ Virtual environment created successfully")
        return True
    except subprocess.CalledProcessError:
        print("  ❌ Failed to create virtual environment")
        return False
    except FileNotFoundError:
        print("  ❌ Backend directory not found")
        return False
    finally:
        os.chdir("..")

def install_dependencies():
    """Install Python dependencies in virtual environment"""
    print("\n📦 Installing Python dependencies...")

    # Determine the correct pip path based on OS
    if os.name == 'nt':  # Windows
        pip_path = "backend/venv/Scripts/pip"
        python_path = "backend/venv/Scripts/python"
    else:  # Linux/Mac
        pip_path = "backend/venv/bin/pip"
        python_path = "backend/venv/bin/python"

    if not os.path.exists(pip_path):
        print("  ❌ Virtual environment not properly created")
        return False

    try:
        subprocess.run([pip_path, "install", "-r", "backend/requirements.txt"], check=True)
        print("  ✅ Dependencies installed successfully")
        return True
    except subprocess.CalledProcessError:
        print("  ❌ Failed to install dependencies")
        return False

def create_database_directory():
    """Create database directory"""
    print("\n🗄️  Setting up database directory...")
    os.makedirs("database", exist_ok=True)
    print("  ✅ Database directory ready")

def test_installation():
    """Test if the installation was successful"""
    print("\n🧪 Testing installation...")

    # Check if all required files exist
    required_files = [
        "backend/app.py",
        "backend/requirements.txt",
        "backend/static/style.css",
        "backend/static/app.js",
        "backend/templates/index.html"
    ]

    missing_files = []
    for file in required_files:
        if not os.path.exists(file):
            missing_files.append(file)

    if missing_files:
        print("  ❌ Missing required files:")
        for file in missing_files:
            print(f"     - {file}")
        return False

    print("  ✅ All required files present")
    return True

def print_completion_message():
    """Print setup completion message with instructions"""
    print("\n" + "=" * 60)
    print("🎉 PATH PILOT Setup Complete!")
    print("=" * 60)
    print("\n📋 Next Steps:")
    print("\n1. 🚀 Start the application:")
    if os.name == 'nt':  # Windows
        print("   Double-click: scripts\\run.bat")
        print("   Or run: scripts\\run.bat")
    else:  # Linux/Mac
        print("   Run: chmod +x scripts/run.sh && ./scripts/run.sh")

    print("\n2. 🌐 Open your web browser and go to:")
    print("   http://localhost:5000")

    print("\n3. 🎮 Start your PATH PILOT adventure:")
    print("   • Create an account")
    print("   • Explore the 5 career guidance levels")
    print("   • Earn achievements and XP")
    print("   • Generate your completion certificate")

    print("\n🎯 Features included:")
    print("   ✅ Gamified career guidance (5 levels)")
    print("   ✅ User authentication and progress tracking")
    print("   ✅ Interactive assessments and quizzes")
    print("   ✅ Beautiful animations and responsive design")
    print("   ✅ Professional certificate generation")

    print("\n📚 Documentation:")
    print("   • README: docs/README.md")
    print("   • Setup Guide: docs/setup-guide.md")

    print("\n🆘 Need help?")
    print("   Check the troubleshooting section in the README file")

    print("\n🌟 Enjoy your PATH PILOT career adventure!")

def main():
    """Main setup function"""
    print_header()

    # Check if we're in the right directory
    if not os.path.exists("backend/app.py"):
        print("❌ Please run this script from the PATH PILOT project root directory")
        print("   The directory should contain 'backend', 'frontend', 'docs', etc.")
        sys.exit(1)

    try:
        check_python_version()

        if not setup_virtual_environment():
            print("\n❌ Setup failed at virtual environment creation")
            sys.exit(1)

        if not install_dependencies():
            print("\n❌ Setup failed at dependency installation")
            sys.exit(1)

        create_database_directory()

        if not test_installation():
            print("\n⚠️  Setup completed with warnings")
            print("   Some files may be missing, but you can try running the application")

        print_completion_message()

    except KeyboardInterrupt:
        print("\n\n⚠️  Setup interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Setup failed with error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
