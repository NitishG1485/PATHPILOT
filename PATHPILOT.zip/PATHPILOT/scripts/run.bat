@echo off
echo 🎮 PATH PILOT - Starting Your Career Adventure
echo ==============================================

REM Check if Python is installed
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo ❌ Python not found. Please install Python 3.8 or higher.
    echo    Download from: https://www.python.org/downloads/
    pause
    exit /b 1
)

echo ✅ Python found
python --version

REM Navigate to backend directory
if not exist "backend" (
    echo ❌ Backend directory not found. Please run this script from the project root.
    pause
    exit /b 1
)

cd backend

REM Check if virtual environment exists, create if not
if not exist "venv" (
    echo 📦 Creating Python virtual environment...
    python -m venv venv
    if %errorlevel% neq 0 (
        echo ❌ Failed to create virtual environment.
        pause
        exit /b 1
    )
    echo ✅ Virtual environment created successfully.
)

REM Activate virtual environment
echo 🔄 Activating virtual environment...
call venv\Scripts\activate.bat

REM Check if requirements are installed
if not exist "venv\pip-installed" (
    echo 📥 Installing Python dependencies...
    pip install -r requirements.txt
    if %errorlevel% equ 0 (
        echo. > venv\pip-installed
        echo ✅ Dependencies installed successfully.
    ) else (
        echo ❌ Failed to install dependencies.
        pause
        exit /b 1
    )
) else (
    echo ✅ Dependencies already installed.
)

REM Create database directory if it doesn't exist
if not exist "..\database" mkdir ..\database

REM Start the application
echo.
echo 🚀 Starting PATH PILOT Application...
echo 🌐 Server will be available at: http://localhost:5000
echo 📱 Open your web browser and navigate to the URL above
echo.
echo 🎯 Ready to start your career adventure!
echo Press Ctrl+C to stop the server
echo.

REM Run the Flask application
python app.py

pause
