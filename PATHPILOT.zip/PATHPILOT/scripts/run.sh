#!/bin/bash

echo "🎮 PATH PILOT - Starting Your Career Adventure"
echo "=============================================="

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Python3 not found. Please install Python 3.8 or higher."
    echo "   Download from: https://www.python.org/downloads/"
    exit 1
fi

echo "✅ Python3 found: $(python3 --version)"

# Navigate to backend directory
if [ ! -d "backend" ]; then
    echo "❌ Backend directory not found. Please run this script from the project root."
    exit 1
fi

cd backend

# Check if virtual environment exists, create if not
if [ ! -d "venv" ]; then
    echo "📦 Creating Python virtual environment..."
    python3 -m venv venv
    if [ $? -ne 0 ]; then
        echo "❌ Failed to create virtual environment."
        exit 1
    fi
    echo "✅ Virtual environment created successfully."
fi

# Activate virtual environment
echo "🔄 Activating virtual environment..."
source venv/bin/activate

# Check if requirements are installed
if [ ! -f "venv/pip-installed" ]; then
    echo "📥 Installing Python dependencies..."
    pip install -r requirements.txt
    if [ $? -eq 0 ]; then
        touch venv/pip-installed
        echo "✅ Dependencies installed successfully."
    else
        echo "❌ Failed to install dependencies."
        exit 1
    fi
else
    echo "✅ Dependencies already installed."
fi

# Create database directory if it doesn't exist
mkdir -p ../database

# Start the application
echo ""
echo "🚀 Starting PATH PILOT Application..."
echo "🌐 Server will be available at: http://localhost:5000"
echo "📱 Open your web browser and navigate to the URL above"
echo ""
echo "🎯 Ready to start your career adventure!"
echo "Press Ctrl+C to stop the server"
echo ""

# Run the Flask application
python app.py
