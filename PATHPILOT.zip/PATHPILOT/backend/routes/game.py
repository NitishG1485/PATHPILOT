"""
Game routes for PATH PILOT
Handles level progression and game mechanics
"""

from flask import Blueprint, request, jsonify, session
import sqlite3
import json
from datetime import datetime

game = Blueprint('game', __name__)

def get_db_connection():
    conn = sqlite3.connect('database/pathpilot.db')
    conn.row_factory = sqlite3.Row
    return conn

@game.route('/progress', methods=['GET', 'POST'])
def handle_progress():
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401

    user_id = session['user_id']

    if request.method == 'GET':
        conn = get_db_connection()
        progress = conn.execute(
            'SELECT * FROM user_progress WHERE user_id = ?',
            (user_id,)
        ).fetchall()

        achievements = conn.execute(
            'SELECT * FROM achievements WHERE user_id = ?',
            (user_id,)
        ).fetchall()

        conn.close()

        return jsonify({
            'progress': [dict(row) for row in progress],
            'achievements': [dict(row) for row in achievements]
        })

    elif request.method == 'POST':
        data = request.get_json()
        level_id = data.get('level_id')
        xp = data.get('xp', 0)
        status = data.get('status', 'in_progress')
        progress_data = json.dumps(data.get('data', {}))

        conn = get_db_connection()

        # Update or insert progress
        existing = conn.execute(
            'SELECT id FROM user_progress WHERE user_id = ? AND level_id = ?',
            (user_id, level_id)
        ).fetchone()

        if existing:
            conn.execute(
                """UPDATE user_progress 
                   SET xp = ?, status = ?, data = ?, completion_date = ?
                   WHERE user_id = ? AND level_id = ?""",
                (xp, status, progress_data, 
                 datetime.now() if status == 'completed' else None,
                 user_id, level_id)
            )
        else:
            conn.execute(
                """INSERT INTO user_progress (user_id, level_id, xp, status, data, completion_date)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (user_id, level_id, xp, status, progress_data,
                 datetime.now() if status == 'completed' else None)
            )

        conn.commit()
        conn.close()

        return jsonify({'success': True})

@game.route('/levels', methods=['GET'])
def get_levels():
    """Get all available game levels"""
    from ..models.levels import LEVELS
    return jsonify({'levels': [level.to_dict() for level in LEVELS]})

@game.route('/achievements', methods=['POST'])
def add_achievement():
    """Add achievement to user"""
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401

    data = request.get_json()
    achievement_name = data.get('achievement_name')

    if not achievement_name:
        return jsonify({'error': 'Achievement name required'}), 400

    user_id = session['user_id']
    conn = get_db_connection()

    # Check if achievement already exists
    existing = conn.execute(
        'SELECT id FROM achievements WHERE user_id = ? AND achievement_name = ?',
        (user_id, achievement_name)
    ).fetchone()

    if not existing:
        conn.execute(
            'INSERT INTO achievements (user_id, achievement_name) VALUES (?, ?)',
            (user_id, achievement_name)
        )
        conn.commit()

    conn.close()
    return jsonify({'success': True})
