"""
API routes for PATH PILOT
General API endpoints and utilities
"""

from flask import Blueprint, request, jsonify, session
import sqlite3
from datetime import datetime

api = Blueprint('api', __name__)

def get_db_connection():
    conn = sqlite3.connect('database/pathpilot.db')
    conn.row_factory = sqlite3.Row
    return conn

@api.route('/certificate', methods=['POST'])
def generate_certificate():
    """Generate completion certificate for user"""
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401

    user_id = session['user_id']

    # Check if user has completed all levels
    conn = get_db_connection()
    completed_levels = conn.execute(
        'SELECT COUNT(*) as count FROM user_progress WHERE user_id = ? AND status = "completed"',
        (user_id,)
    ).fetchone()

    user = conn.execute(
        'SELECT full_name FROM users WHERE id = ?',
        (user_id,)
    ).fetchone()

    conn.close()

    if completed_levels['count'] >= 5:  # All 5 levels completed
        certificate_data = {
            'user_name': user['full_name'],
            'completion_date': datetime.now().strftime('%B %d, %Y'),
            'certificate_id': f'PP-{user_id:04d}-{datetime.now().strftime("%Y%m%d")}',
            'founder_signature': 'Nitish.G'
        }
        return jsonify({'success': True, 'certificate': certificate_data})
    else:
        return jsonify({'error': 'Not all levels completed'}), 400

@api.route('/user/profile', methods=['GET'])
def get_user_profile():
    """Get current user profile"""
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401

    user_id = session['user_id']
    conn = get_db_connection()

    user = conn.execute(
        'SELECT id, username, email, full_name, created_at FROM users WHERE id = ?',
        (user_id,)
    ).fetchone()

    if not user:
        conn.close()
        return jsonify({'error': 'User not found'}), 404

    # Get user statistics
    total_xp = conn.execute(
        'SELECT COALESCE(SUM(xp), 0) as total_xp FROM user_progress WHERE user_id = ?',
        (user_id,)
    ).fetchone()

    completed_levels = conn.execute(
        'SELECT COUNT(*) as count FROM user_progress WHERE user_id = ? AND status = "completed"',
        (user_id,)
    ).fetchone()

    achievements_count = conn.execute(
        'SELECT COUNT(*) as count FROM achievements WHERE user_id = ?',
        (user_id,)
    ).fetchone()

    conn.close()

    return jsonify({
        'user': dict(user),
        'stats': {
            'totalXp': total_xp['total_xp'],
            'completedLevels': completed_levels['count'],
            'achievementsCount': achievements_count['count']
        }
    })

@api.route('/leaderboard', methods=['GET'])
def get_leaderboard():
    """Get top users leaderboard"""
    conn = get_db_connection()

    leaderboard = conn.execute("""
        SELECT u.username, u.full_name, COALESCE(SUM(up.xp), 0) as total_xp,
               COUNT(CASE WHEN up.status = 'completed' THEN 1 END) as completed_levels
        FROM users u
        LEFT JOIN user_progress up ON u.id = up.user_id
        GROUP BY u.id, u.username, u.full_name
        ORDER BY total_xp DESC, completed_levels DESC
        LIMIT 10
    """).fetchall()

    conn.close()

    return jsonify({
        'leaderboard': [dict(row) for row in leaderboard]
    })
