"""
Authentication routes for PATH PILOT
Handles user registration, login, and logout
"""

from flask import Blueprint, request, jsonify, session
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3

auth = Blueprint('auth', __name__)

def get_db_connection():
    conn = sqlite3.connect('database/pathpilot.db')
    conn.row_factory = sqlite3.Row
    return conn

@auth.route('/register', methods=['POST'])
def register():
    data = request.get_json()
    username = data.get('username')
    email = data.get('email')
    password = data.get('password')
    full_name = data.get('fullName')

    if not all([username, email, password, full_name]):
        return jsonify({'error': 'All fields are required'}), 400

    conn = get_db_connection()

    # Check if user already exists
    existing_user = conn.execute(
        'SELECT id FROM users WHERE username = ? OR email = ?',
        (username, email)
    ).fetchone()

    if existing_user:
        conn.close()
        return jsonify({'error': 'Username or email already exists'}), 400

    # Create new user
    password_hash = generate_password_hash(password)
    try:
        conn.execute(
            'INSERT INTO users (username, email, password_hash, full_name) VALUES (?, ?, ?, ?)',
            (username, email, password_hash, full_name)
        )
        conn.commit()

        # Get the new user
        user = conn.execute(
            'SELECT id, username, email, full_name FROM users WHERE username = ?',
            (username,)
        ).fetchone()

        conn.close()

        session['user_id'] = user['id']
        session['username'] = user['username']

        return jsonify({
            'success': True,
            'user': {
                'id': user['id'],
                'username': user['username'],
                'email': user['email'],
                'fullName': user['full_name']
            }
        })

    except Exception as e:
        conn.close()
        return jsonify({'error': 'Registration failed'}), 500

@auth.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')

    if not username or not password:
        return jsonify({'error': 'Username and password required'}), 400

    conn = get_db_connection()
    user = conn.execute(
        'SELECT * FROM users WHERE username = ?',
        (username,)
    ).fetchone()
    conn.close()

    if user and check_password_hash(user['password_hash'], password):
        session['user_id'] = user['id']
        session['username'] = user['username']

        return jsonify({
            'success': True,
            'user': {
                'id': user['id'],
                'username': user['username'],
                'email': user['email'],
                'fullName': user['full_name']
            }
        })
    else:
        return jsonify({'error': 'Invalid credentials'}), 401

@auth.route('/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({'success': True})
