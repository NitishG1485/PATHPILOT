"""
Levels model for PATH PILOT application
Defines the 5 career guidance levels
"""

class Level:
    def __init__(self, id, name, description, icon, xp_reward=1000, content=None):
        self.id = id
        self.name = name
        self.description = description
        self.icon = icon
        self.xp_reward = xp_reward
        self.content = content or {}

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'icon': self.icon,
            'xpReward': self.xp_reward,
            'content': self.content
        }

# Define the 5 PATH PILOT levels
LEVELS = [
    Level(
        id=1,
        name="Stream Selection Grove",
        description="Choose your academic path - Science, Commerce, or Arts",
        icon="🌳",
        content={
            "streams": [
                {
                    "name": "Science",
                    "subjects": ["Physics", "Chemistry", "Biology/Mathematics"],
                    "careers": ["Doctor", "Engineer", "Researcher", "Data Scientist"],
                    "description": "Ideal for analytical minds interested in medicine, engineering, and technology"
                },
                {
                    "name": "Commerce", 
                    "subjects": ["Accountancy", "Business Studies", "Economics", "Mathematics"],
                    "careers": ["CA", "Business Manager", "Banker", "Entrepreneur"],
                    "description": "Perfect for those interested in business, finance, and management"
                },
                {
                    "name": "Arts/Humanities",
                    "subjects": ["History", "Geography", "Political Science", "Psychology"],
                    "careers": ["Lawyer", "Journalist", "Civil Servant", "Teacher"],
                    "description": "Great for creative minds interested in social sciences and communication"
                }
            ]
        }
    ),
    Level(
        id=2,
        name="Skill Discovery Forest",
        description="Discover your strengths and develop essential skills",
        icon="🧭",
        content={
            "assessments": [
                {
                    "type": "Personality Test",
                    "questions": [
                        "I prefer working with data over people",
                        "I enjoy solving complex problems",
                        "I like organizing and planning events", 
                        "I find satisfaction in helping others",
                        "I enjoy creative and artistic activities"
                    ]
                }
            ]
        }
    ),
    Level(
        id=3,
        name="College Selection Meadow",
        description="Find the perfect college and course for your goals",
        icon="🏛️",
        content={
            "selection_criteria": [
                "Course curriculum and specializations",
                "College ranking and accreditation", 
                "Infrastructure and facilities",
                "Placement records and alumni network",
                "Fee structure and financial aid",
                "Location and campus life"
            ]
        }
    ),
    Level(
        id=4,
        name="Internship Valley",
        description="Secure valuable internship opportunities",
        icon="💼",
        content={
            "platforms": ["Internshala", "LinkedIn", "Indeed", "Company Websites"],
            "resume_tips": [
                "Highlight relevant coursework and projects",
                "Include technical and soft skills",
                "Quantify achievements with numbers",
                "Customize for each application",
                "Keep it concise and well-formatted"
            ]
        }
    ),
    Level(
        id=5,
        name="Career Summit",
        description="Land your dream job and plan your career growth",
        icon="🎯",
        content={
            "job_search_strategies": [
                "Build a strong professional network",
                "Optimize your LinkedIn profile", 
                "Apply through multiple channels",
                "Follow up professionally",
                "Prepare for various interview formats"
            ]
        }
    )
]
