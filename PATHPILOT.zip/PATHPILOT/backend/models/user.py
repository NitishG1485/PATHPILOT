"""
User model for PATH PILOT application
Handles user data and authentication
"""

class User:
    def __init__(self, id=None, username=None, email=None, full_name=None, created_at=None):
        self.id = id
        self.username = username
        self.email = email
        self.full_name = full_name
        self.created_at = created_at

    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'email': self.email,
            'fullName': self.full_name,
            'createdAt': self.created_at
        }

    def __repr__(self):
        return f'<User {self.username}>'
