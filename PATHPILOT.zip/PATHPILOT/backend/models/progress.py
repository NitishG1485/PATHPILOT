"""
Progress model for PATH PILOT application
Handles user progress tracking across levels
"""

import json
from datetime import datetime

class UserProgress:
    def __init__(self, id=None, user_id=None, level_id=None, xp=0, 
                 status='not_started', completion_date=None, data=None):
        self.id = id
        self.user_id = user_id
        self.level_id = level_id
        self.xp = xp
        self.status = status
        self.completion_date = completion_date
        self.data = data or {}

    def to_dict(self):
        return {
            'id': self.id,
            'userId': self.user_id,
            'levelId': self.level_id,
            'xp': self.xp,
            'status': self.status,
            'completionDate': self.completion_date,
            'data': self.data if isinstance(self.data, dict) else json.loads(self.data)
        }

    def __repr__(self):
        return f'<UserProgress User:{self.user_id} Level:{self.level_id}>'
