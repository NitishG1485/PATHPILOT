// PATH PILOT - Gamified Career Guidance Application
// Main JavaScript functionality

class PathPilotApp {
    constructor() {
        this.currentUser = null;
        this.currentLevel = 1;
        this.userProgress = {
            xp: 0,
            achievements: [],
            levelsCompleted: [],
            streak: 0,
            lastLoginDate: null,
            skills: {
                'Communication': 0,
                'Leadership': 0,
                'Problem-solving': 0,
                'Creativity': 0,
                'Technical Skills': 0
            }
        };

        this.levels = [
            {
                id: 1,
                name: "Stream Selection Grove",
                description: "Choose your academic path - Science, Commerce, or Arts",
                icon: "🌳",
                xpReward: 1000,
                content: {
                    streams: [
                        {
                            name: "Science",
                            subjects: ["Physics", "Chemistry", "Biology/Mathematics"],
                            careers: ["Doctor", "Engineer", "Researcher", "Data Scientist"],
                            description: "Ideal for analytical minds interested in medicine, engineering, and technology"
                        },
                        {
                            name: "Commerce",
                            subjects: ["Accountancy", "Business Studies", "Economics", "Mathematics"],
                            careers: ["CA", "Business Manager", "Banker", "Entrepreneur"],
                            description: "Perfect for those interested in business, finance, and management"
                        },
                        {
                            name: "Arts/Humanities",
                            subjects: ["History", "Geography", "Political Science", "Psychology"],
                            careers: ["Lawyer", "Journalist", "Civil Servant", "Teacher"],
                            description: "Great for creative minds interested in social sciences and communication"
                        }
                    ]
                }
            },
            {
                id: 2,
                name: "Skill Discovery Forest",
                description: "Discover your strengths and develop essential skills",
                icon: "🧭",
                xpReward: 1000,
                content: {
                    assessments: [
                        {
                            type: "Personality Test",
                            questions: [
                                "I prefer working with data over people",
                                "I enjoy solving complex problems",
                                "I like organizing and planning events", 
                                "I find satisfaction in helping others",
                                "I enjoy creative and artistic activities"
                            ]
                        },
                        {
                            type: "Interest Assessment", 
                            categories: ["Technical", "Creative", "Social", "Business", "Analytical"]
                        },
                        {
                            type: "Skill Evaluation",
                            skills: ["Communication", "Leadership", "Problem-solving", "Creativity", "Technical Skills"]
                        }
                    ]
                }
            },
            {
                id: 3,
                name: "College Selection Meadow",
                description: "Find the perfect college and course for your goals",
                icon: "🏛️",
                xpReward: 1000,
                content: {
                    selection_criteria: [
                        "Course curriculum and specializations",
                        "College ranking and accreditation", 
                        "Infrastructure and facilities",
                        "Placement records and alumni network",
                        "Fee structure and financial aid",
                        "Location and campus life"
                    ],
                    course_types: ["Engineering", "Medical", "Business", "Arts", "Law", "Design"],
                    tips: [
                        "Research multiple colleges in your preferred field",
                        "Check admission requirements and cutoff scores",
                        "Visit college websites and attend virtual tours",
                        "Connect with current students and alumni",
                        "Consider both academic and extracurricular opportunities"
                    ]
                }
            },
            {
                id: 4,
                name: "Internship Valley",
                description: "Secure valuable internship opportunities",
                icon: "💼",
                xpReward: 1000,
                content: {
                    platforms: ["Internshala", "LinkedIn", "Indeed", "Company Websites"],
                    resume_tips: [
                        "Highlight relevant coursework and projects",
                        "Include technical and soft skills",
                        "Quantify achievements with numbers",
                        "Customize for each application",
                        "Keep it concise and well-formatted"
                    ],
                    interview_prep: [
                        "Research the company thoroughly",
                        "Practice common interview questions",
                        "Prepare STAR method examples",
                        "Dress professionally",
                        "Ask thoughtful questions"
                    ],
                    application_tips: [
                        "Apply early and widely",
                        "Follow up on applications",
                        "Network with professionals",
                        "Build an online portfolio",
                        "Prepare for online assessments"
                    ]
                }
            },
            {
                id: 5,
                name: "Career Summit",
                description: "Land your dream job and plan your career growth",
                icon: "🎯",
                xpReward: 1000,
                content: {
                    job_search_strategies: [
                        "Build a strong professional network",
                        "Optimize your LinkedIn profile", 
                        "Apply through multiple channels",
                        "Follow up professionally",
                        "Prepare for various interview formats"
                    ],
                    career_planning: [
                        "Set short-term and long-term goals",
                        "Identify required skills and certifications",
                        "Build a professional brand",
                        "Seek mentorship opportunities",
                        "Plan for continuous learning"
                    ],
                    growth_tips: [
                        "Excel in your current role",
                        "Take on additional responsibilities",
                        "Build cross-functional skills",
                        "Stay updated with industry trends",
                        "Maintain professional relationships"
                    ]
                }
            }
        ];

        this.achievements = [
            {name: "Stream Explorer", description: "Completed Level 1", icon: "🌟"},
            {name: "Self Aware", description: "Completed skill assessment", icon: "💎"},
            {name: "College Ready", description: "Researched 5+ colleges", icon: "🏆"},
            {name: "Intern Hunter", description: "Built professional resume", icon: "🎖️"},
            {name: "Career Champion", description: "Completed all levels", icon: "👑"}
        ];

        this.apiBaseUrl = '/api';
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.createParticles();
        this.checkAuthStatus();
    }

    setupEventListeners() {
        // Form submissions
        document.getElementById('login-form')?.addEventListener('submit', (e) => this.handleLogin(e));
        document.getElementById('register-form')?.addEventListener('submit', (e) => this.handleRegister(e));

        // Level preview cards
        document.querySelectorAll('.level-card.preview').forEach(card => {
            card.addEventListener('click', () => {
                if (this.currentUser) {
                    this.showLevels();
                } else {
                    this.showRegister();
                }
            });
        });
    }

    createParticles() {
        const container = document.getElementById('particles-container');
        if (!container) return;

        // Create floating particles
        for (let i = 0; i < 50; i++) {
            const particle = document.createElement('div');
            particle.className = 'particle';
            particle.style.cssText = `
                position: absolute;
                width: 2px;
                height: 2px;
                background: rgba(255, 215, 0, 0.6);
                border-radius: 50%;
                left: ${Math.random() * 100}%;
                top: ${Math.random() * 100}%;
                animation: float ${5 + Math.random() * 10}s ease-in-out infinite;
                animation-delay: ${Math.random() * 5}s;
            `;
            container.appendChild(particle);
        }

        // Add floating animation
        const style = document.createElement('style');
        style.textContent = `
            @keyframes float {
                0%, 100% { transform: translateY(0px) translateX(0px); opacity: 0; }
                10% { opacity: 1; }
                50% { transform: translateY(-100px) translateX(50px); opacity: 0.8; }
                90% { opacity: 1; }
            }
        `;
        document.head.appendChild(style);
    }

    // API Methods
    async makeRequest(endpoint, method = 'GET', data = null) {
        try {
            const options = {
                method,
                headers: {
                    'Content-Type': 'application/json',
                },
                credentials: 'include' // Include session cookies
            };

            if (data) {
                options.body = JSON.stringify(data);
            }

            const response = await fetch(`${this.apiBaseUrl}${endpoint}`, options);
            const result = await response.json();

            if (!response.ok) {
                throw new Error(result.error || 'Request failed');
            }

            return result;
        } catch (error) {
            console.error(`API Error (${endpoint}):`, error);
            throw error;
        }
    }

    // Authentication Methods
    async handleLogin(event) {
        event.preventDefault();

        const username = document.getElementById('login-username').value;
        const password = document.getElementById('login-password').value;

        try {
            this.showLoading('login-form');
            const result = await this.makeRequest('/login', 'POST', { username, password });

            if (result.success) {
                this.currentUser = result.user;
                this.showSuccessMessage('Welcome back, ' + result.user.fullName + '!');
                await this.loadUserProgress();
                this.showDashboard();
            }
        } catch (error) {
            this.showErrorMessage(error.message);
        } finally {
            this.hideLoading('login-form');
        }
    }

    async handleRegister(event) {
        event.preventDefault();

        const fullName = document.getElementById('register-fullname').value;
        const username = document.getElementById('register-username').value;
        const email = document.getElementById('register-email').value;
        const password = document.getElementById('register-password').value;

        try {
            this.showLoading('register-form');
            const result = await this.makeRequest('/register', 'POST', {
                fullName, username, email, password
            });

            if (result.success) {
                this.currentUser = result.user;
                this.showSuccessMessage('Welcome to PATH PILOT, ' + result.user.fullName + '!');
                await this.loadUserProgress();
                this.showDashboard();
            }
        } catch (error) {
            this.showErrorMessage(error.message);
        } finally {
            this.hideLoading('register-form');
        }
    }

    async logout() {
        try {
            await this.makeRequest('/logout', 'POST');
            this.currentUser = null;
            this.userProgress = {
                xp: 0,
                achievements: [],
                levelsCompleted: [],
                streak: 0,
                lastLoginDate: null,
                skills: {
                    'Communication': 0,
                    'Leadership': 0,
                    'Problem-solving': 0,
                    'Creativity': 0,
                    'Technical Skills': 0
                }
            };
            this.showLanding();
            this.showSuccessMessage('Successfully logged out!');
        } catch (error) {
            this.showErrorMessage('Logout failed');
        }
    }

    async checkAuthStatus() {
        try {
            const result = await this.makeRequest('/progress', 'GET');
            if (result.progress) {
                // User is authenticated
                await this.loadUserProgress();
                // Don't auto-redirect to dashboard, stay on landing page
            }
        } catch (error) {
            // User is not authenticated, stay on landing page
            console.log('User not authenticated');
        }
    }

    // Progress Management
    async loadUserProgress() {
        try {
            const result = await this.makeRequest('/progress', 'GET');

            if (result.progress) {
                this.userProgress.levelsCompleted = result.progress
                    .filter(p => p.status === 'completed')
                    .map(p => p.level_id);

                this.userProgress.xp = result.progress
                    .reduce((total, p) => total + (p.xp || 0), 0);

                this.userProgress.achievements = result.achievements || [];
            }

            this.updateProgressDisplay();
        } catch (error) {
            console.error('Failed to load progress:', error);
        }
    }

    async saveProgress(levelId, xp, status = 'in_progress', data = {}) {
        try {
            await this.makeRequest('/progress', 'POST', {
                level_id: levelId,
                xp: xp,
                status: status,
                data: data
            });

            // Update local progress
            if (status === 'completed' && !this.userProgress.levelsCompleted.includes(levelId)) {
                this.userProgress.levelsCompleted.push(levelId);
                this.userProgress.xp += xp;
                this.checkForAchievements();
            }

            this.updateProgressDisplay();
        } catch (error) {
            console.error('Failed to save progress:', error);
            throw error;
        }
    }

    checkForAchievements() {
        const completedCount = this.userProgress.levelsCompleted.length;

        // Award achievements based on progress
        if (completedCount >= 1 && !this.userProgress.achievements.includes("Stream Explorer")) {
            this.awardAchievement("Stream Explorer");
        }
        if (completedCount >= 2 && !this.userProgress.achievements.includes("Self Aware")) {
            this.awardAchievement("Self Aware");
        }
        if (completedCount >= 3 && !this.userProgress.achievements.includes("College Ready")) {
            this.awardAchievement("College Ready");
        }
        if (completedCount >= 4 && !this.userProgress.achievements.includes("Intern Hunter")) {
            this.awardAchievement("Intern Hunter");
        }
        if (completedCount >= 5 && !this.userProgress.achievements.includes("Career Champion")) {
            this.awardAchievement("Career Champion");
            this.showCompletion();
        }
    }

    async awardAchievement(achievementName) {
        try {
            await this.makeRequest('/achievements', 'POST', {
                achievement_name: achievementName
            });

            this.userProgress.achievements.push(achievementName);
            this.showAchievementNotification(achievementName);
        } catch (error) {
            console.error('Failed to award achievement:', error);
        }
    }

    // Level Management
    startLevel(levelId) {
        const level = this.levels.find(l => l.id === levelId);
        if (!level) return;

        this.showLevelModal(level);
    }

    showLevelModal(level) {
        const modal = document.getElementById('level-modal');
        const title = document.getElementById('level-modal-title');
        const body = document.getElementById('level-modal-body');

        title.textContent = `${level.icon} ${level.name}`;
        body.innerHTML = this.generateLevelContent(level);

        modal.classList.add('active');
        this.currentLevel = level.id;
    }

    generateLevelContent(level) {
        switch(level.id) {
            case 1: return this.generateStreamSelectionContent(level);
            case 2: return this.generateSkillAssessmentContent(level);
            case 3: return this.generateCollegeSelectionContent(level);
            case 4: return this.generateInternshipContent(level);
            case 5: return this.generateCareerContent(level);
            default: return '<p>Level content coming soon!</p>';
        }
    }

    generateStreamSelectionContent(level) {
        return `
            <div class="level-content-wrapper">
                <h4>Choose Your Academic Stream</h4>
                <p>Your academic stream choice will shape your career path. Explore each option:</p>

                <div class="stream-options">
                    ${level.content.streams.map(stream => `
                        <div class="stream-card" onclick="selectStream('${stream.name}')">
                            <h5>${stream.name}</h5>
                            <p>${stream.description}</p>
                            <div class="stream-details">
                                <strong>Key Subjects:</strong>
                                <ul>
                                    ${stream.subjects.map(subject => `<li>${subject}</li>`).join('')}
                                </ul>
                                <strong>Career Options:</strong>
                                <ul>
                                    ${stream.careers.map(career => `<li>${career}</li>`).join('')}
                                </ul>
                            </div>
                        </div>
                    `).join('')}
                </div>

                <div class="level-quiz">
                    <h5>Quick Assessment</h5>
                    <p>Which activities interest you most?</p>
                    <div class="quiz-options">
                        <label><input type="radio" name="interest" value="science"> Conducting experiments and analyzing data</label>
                        <label><input type="radio" name="interest" value="commerce"> Managing businesses and financial planning</label>
                        <label><input type="radio" name="interest" value="arts"> Writing, debating, and understanding society</label>
                    </div>
                </div>
            </div>
        `;
    }

    generateSkillAssessmentContent(level) {
        return `
            <div class="level-content-wrapper">
                <h4>Discover Your Skills & Strengths</h4>
                <p>Complete these assessments to understand your abilities better:</p>

                <div class="assessment-section">
                    <h5>Personality Assessment</h5>
                    <div class="personality-questions">
                        ${level.content.assessments[0].questions.map((question, index) => `
                            <div class="question-item">
                                <p>${question}</p>
                                <div class="rating-scale">
                                    ${[1,2,3,4,5].map(rating => `
                                        <label>
                                            <input type="radio" name="q${index}" value="${rating}">
                                            <span class="rating-label">${rating}</span>
                                        </label>
                                    `).join('')}
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>

                <div class="skills-evaluation">
                    <h5>Rate Your Current Skills</h5>
                    <div class="skills-grid">
                        ${['Communication', 'Leadership', 'Problem-solving', 'Creativity', 'Technical Skills'].map(skill => `
                            <div class="skill-item">
                                <label>${skill}</label>
                                <input type="range" min="1" max="10" value="5" class="skill-slider" data-skill="${skill}">
                                <span class="skill-value">5</span>
                            </div>
                        `).join('')}
                    </div>
                </div>
            </div>
        `;
    }

    generateCollegeSelectionContent(level) {
        return `
            <div class="level-content-wrapper">
                <h4>Find Your Perfect College</h4>
                <p>Use these criteria to evaluate and select the right college:</p>

                <div class="selection-criteria">
                    <h5>Key Selection Factors</h5>
                    <div class="criteria-list">
                        ${level.content.selection_criteria.map(criteria => `
                            <div class="criteria-item">
                                <input type="checkbox" id="${criteria.replace(/\s+/g, '_')}" value="${criteria}">
                                <label for="${criteria.replace(/\s+/g, '_')}">${criteria}</label>
                            </div>
                        `).join('')}
                    </div>
                </div>

                <div class="course-types">
                    <h5>Popular Course Categories</h5>
                    <div class="course-grid">
                        ${level.content.course_types.map(course => `
                            <div class="course-card" onclick="selectCourse('${course}')">
                                <h6>${course}</h6>
                            </div>
                        `).join('')}
                    </div>
                </div>

                <div class="college-tips">
                    <h5>Expert Tips</h5>
                    <ul>
                        ${level.content.tips.map(tip => `<li>${tip}</li>`).join('')}
                    </ul>
                </div>
            </div>
        `;
    }

    generateInternshipContent(level) {
        return `
            <div class="level-content-wrapper">
                <h4>Secure Your Dream Internship</h4>
                <p>Master the art of finding and landing internships:</p>

                <div class="internship-platforms">
                    <h5>Top Internship Platforms</h5>
                    <div class="platform-list">
                        ${level.content.platforms.map(platform => `
                            <div class="platform-item">
                                <strong>${platform}</strong>
                                <p>Explore opportunities and apply directly</p>
                            </div>
                        `).join('')}
                    </div>
                </div>

                <div class="resume-section">
                    <h5>Resume Building Tips</h5>
                    <ul>
                        ${level.content.resume_tips.map(tip => `<li>${tip}</li>`).join('')}
                    </ul>
                </div>

                <div class="interview-prep">
                    <h5>Interview Preparation</h5>
                    <ul>
                        ${level.content.interview_prep.map(tip => `<li>${tip}</li>`).join('')}
                    </ul>
                </div>

                <div class="application-strategy">
                    <h5>Application Strategy</h5>
                    <ul>
                        ${level.content.application_tips.map(tip => `<li>${tip}</li>`).join('')}
                    </ul>
                </div>
            </div>
        `;
    }

    generateCareerContent(level) {
        return `
            <div class="level-content-wrapper">
                <h4>Launch Your Career</h4>
                <p>Strategies for landing your dream job and planning long-term success:</p>

                <div class="job-search">
                    <h5>Job Search Strategies</h5>
                    <ul>
                        ${level.content.job_search_strategies.map(strategy => `<li>${strategy}</li>`).join('')}
                    </ul>
                </div>

                <div class="career-planning">
                    <h5>Career Planning</h5>
                    <ul>
                        ${level.content.career_planning.map(plan => `<li>${plan}</li>`).join('')}
                    </ul>
                </div>

                <div class="growth-tips">
                    <h5>Professional Growth Tips</h5>
                    <ul>
                        ${level.content.growth_tips.map(tip => `<li>${tip}</li>`).join('')}
                    </ul>
                </div>
            </div>
        `;
    }

    async completeLevel() {
        try {
            await this.saveProgress(this.currentLevel, this.levels[this.currentLevel - 1].xpReward, 'completed');
            this.showSuccessMessage(`Level ${this.currentLevel} completed! +${this.levels[this.currentLevel - 1].xpReward} XP`);
            this.closeLevelModal();
            this.updateLevelProgress();
        } catch (error) {
            this.showErrorMessage('Failed to save progress');
        }
    }

    closeLevelModal() {
        const modal = document.getElementById('level-modal');
        modal.classList.remove('active');
    }

    // Certificate Generation
    async generateCertificate() {
        try {
            const result = await this.makeRequest('/certificate', 'POST');

            if (result.success) {
                this.displayCertificate(result.certificate);
            }
        } catch (error) {
            this.showErrorMessage(error.message);
        }
    }

    displayCertificate(certificateData) {
        document.getElementById('certificate-name').textContent = certificateData.user_name;
        document.getElementById('certificate-date').textContent = certificateData.completion_date;
        document.getElementById('certificate-id').textContent = certificateData.certificate_id;
    }

    downloadCertificate() {
        const certificate = document.getElementById('certificate');

        // Create a new window for printing
        const printWindow = window.open('', '_blank');
        printWindow.document.write(`
            <!DOCTYPE html>
            <html>
            <head>
                <title>PATH PILOT Certificate</title>
                <style>
                    body { font-family: Arial, sans-serif; margin: 0; padding: 20px; }
                    .certificate { 
                        max-width: 800px; 
                        margin: 0 auto; 
                        border: 3px solid #2d7a32; 
                        padding: 40px; 
                        text-align: center; 
                    }
                    h1 { color: #2d7a32; font-size: 2.5rem; }
                    h2 { color: #1b4d20; font-size: 1.8rem; }
                    .certificate-name { 
                        color: #2d7a32; 
                        font-size: 2rem; 
                        text-decoration: underline; 
                        margin: 20px 0; 
                    }
                    .certificate-title h4 {
                        background: #2d7a32;
                        color: white;
                        padding: 15px 30px;
                        border-radius: 25px;
                        display: inline-block;
                        margin: 20px 0;
                    }
                    .signature-name {
                        font-size: 1.5rem;
                        font-weight: bold;
                        border-bottom: 2px solid #333;
                        display: inline-block;
                        padding-bottom: 10px;
                        margin-top: 50px;
                    }
                </style>
            </head>
            <body>
                ${certificate.innerHTML}
            </body>
            </html>
        `);
        printWindow.document.close();
        printWindow.print();
    }

    shareCertificate() {
        const certificateText = `I just completed the PATH PILOT career guidance program and earned my PathPilot Certified Self Analyzer certification! 🎉`;

        if (navigator.share) {
            navigator.share({
                title: 'PATH PILOT Certificate',
                text: certificateText,
                url: window.location.href
            });
        } else {
            // Fallback for browsers without native sharing
            navigator.clipboard.writeText(certificateText + ' ' + window.location.href);
            this.showSuccessMessage('Certificate details copied to clipboard!');
        }
    }

    // UI Update Methods
    updateProgressDisplay() {
        // Update circular progress
        const progressPercentage = (this.userProgress.levelsCompleted.length / 5) * 100;
        const progressRing = document.querySelector('.progress-ring__circle');
        const progressText = document.querySelector('.progress-percentage');

        if (progressRing) {
            const circumference = 2 * Math.PI * 52;
            const offset = circumference - (progressPercentage / 100) * circumference;
            progressRing.style.strokeDasharray = `${circumference} ${circumference}`;
            progressRing.style.strokeDashoffset = offset;
        }

        if (progressText) {
            progressText.textContent = `${Math.round(progressPercentage)}%`;
        }

        // Update stats
        if (document.getElementById('total-xp')) {
            document.getElementById('total-xp').textContent = this.userProgress.xp;
        }
        if (document.getElementById('levels-completed')) {
            document.getElementById('levels-completed').textContent = this.userProgress.levelsCompleted.length;
        }
        if (document.getElementById('achievements-earned')) {
            document.getElementById('achievements-earned').textContent = this.userProgress.achievements.length;
        }

        // Update user welcome message
        if (this.currentUser && document.getElementById('user-welcome')) {
            document.getElementById('user-welcome').textContent = `Welcome, ${this.currentUser.fullName}!`;
        }
    }

    updateLevelProgress() {
        this.userProgress.levelsCompleted.forEach(levelId => {
            const levelCard = document.querySelector(`[data-level="${levelId}"]`);
            if (levelCard) {
                const progressBar = levelCard.querySelector('.progress-fill');
                const progressText = levelCard.querySelector('.progress-text');
                const button = levelCard.querySelector('.btn--level');

                if (progressBar) progressBar.style.width = '100%';
                if (progressText) progressText.textContent = '100% Complete';
                if (button) {
                    button.textContent = 'Completed ✓';
                    button.classList.add('completed');
                }
            }
        });
    }

    // Navigation Methods
    showPage(pageId) {
        document.querySelectorAll('.page').forEach(page => {
            page.classList.remove('active');
        });

        const targetPage = document.getElementById(pageId);
        if (targetPage) {
            targetPage.classList.add('active');
        }
    }

    showLanding() { this.showPage('landing-page'); }
    showLogin() { this.showPage('login-page'); }
    showRegister() { this.showPage('register-page'); }
    showDashboard() { 
        if (!this.currentUser) {
            this.showLogin();
            return;
        }
        this.showPage('dashboard-page'); 
        this.updateProgressDisplay();
    }
    showLevels() { 
        if (!this.currentUser) {
            this.showLogin();
            return;
        }
        this.showPage('levels-page'); 
        this.updateLevelProgress();
    }
    showProgress() { 
        if (!this.currentUser) {
            this.showLogin();
            return;
        }
        this.showPage('progress-page'); 
    }
    showCertificate() { 
        if (!this.currentUser) {
            this.showLogin();
            return;
        }
        this.showPage('certificate-page'); 
        this.generateCertificate();
    }
    showCompletion() { 
        this.showPage('completion-page');
        // Update final stats
        if (document.getElementById('final-xp')) {
            document.getElementById('final-xp').textContent = this.userProgress.xp;
        }
        if (document.getElementById('final-achievements')) {
            document.getElementById('final-achievements').textContent = this.userProgress.achievements.length;
        }
    }

    // Utility Methods
    showLoading(formId) {
        const form = document.getElementById(formId);
        const button = form?.querySelector('button[type="submit"]');
        if (button) {
            button.innerHTML = '<span class="loading"></span> Loading...';
            button.disabled = true;
        }
    }

    hideLoading(formId) {
        const form = document.getElementById(formId);
        const button = form?.querySelector('button[type="submit"]');
        if (button) {
            button.disabled = false;
            if (formId === 'login-form') {
                button.innerHTML = '<i class="fas fa-sign-in-alt"></i> Enter Adventure';
            } else {
                button.innerHTML = '<i class="fas fa-magic"></i> Create Adventure';
            }
        }
    }

    showSuccessMessage(message) {
        this.showNotification(message, 'success');
    }

    showErrorMessage(message) {
        this.showNotification(message, 'error');
    }

    showNotification(message, type) {
        const notification = document.createElement('div');
        notification.className = `notification notification--${type}`;
        notification.innerHTML = `
            <div class="notification-content">
                <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
                <span>${message}</span>
            </div>
        `;

        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 2000;
            background: ${type === 'success' ? '#4caf50' : '#f44336'};
            color: white;
            padding: 1rem 1.5rem;
            border-radius: 8px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.3);
            transform: translateX(100%);
            transition: transform 0.3s ease;
        `;

        document.body.appendChild(notification);

        setTimeout(() => {
            notification.style.transform = 'translateX(0)';
        }, 100);

        setTimeout(() => {
            notification.style.transform = 'translateX(100%)';
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 300);
        }, 3000);
    }

    showAchievementNotification(achievementName) {
        const achievement = this.achievements.find(a => a.name === achievementName);
        if (!achievement) return;

        const notification = document.createElement('div');
        notification.className = 'achievement-notification';
        notification.innerHTML = `
            <div class="achievement-content">
                <div class="achievement-icon">${achievement.icon}</div>
                <div class="achievement-text">
                    <h4>Achievement Unlocked!</h4>
                    <p><strong>${achievement.name}</strong></p>
                    <p>${achievement.description}</p>
                </div>
            </div>
        `;

        notification.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%) scale(0);
            z-index: 2000;
            background: linear-gradient(135deg, #ffd700, #daa520);
            color: #1b4d20;
            padding: 2rem;
            border-radius: 16px;
            box-shadow: 0 8px 40px rgba(255, 215, 0, 0.5);
            text-align: center;
            max-width: 400px;
            animation: achievementPop 3s ease-out;
        `;

        document.body.appendChild(notification);

        setTimeout(() => {
            if (document.body.contains(notification)) {
                document.body.removeChild(notification);
            }
        }, 3000);
    }
}

// Global functions for onclick events
function showLogin() { app.showLogin(); }
function showRegister() { app.showRegister(); }
function showLanding() { app.showLanding(); }
function showDashboard() { app.showDashboard(); }
function showLevels() { app.showLevels(); }
function showProgress() { app.showProgress(); }
function showCertificate() { app.showCertificate(); }
function logout() { app.logout(); }
function startLevel(levelId) { app.startLevel(levelId); }
function completeLevel() { app.completeLevel(); }
function closeLevelModal() { app.closeLevelModal(); }
function downloadCertificate() { app.downloadCertificate(); }
function shareCertificate() { app.shareCertificate(); }

// Stream and course selection functions
function selectStream(streamName) {
    console.log('Selected stream:', streamName);
    app.showSuccessMessage(`Great choice! ${streamName} stream selected.`);
}

function selectCourse(courseName) {
    console.log('Selected course:', courseName);
    app.showSuccessMessage(`${courseName} added to your interests!`);
}

// Initialize the application
let app;
document.addEventListener('DOMContentLoaded', () => {
    app = new PathPilotApp();
});

// Add CSS animations for achievements
const achievementStyles = document.createElement('style');
achievementStyles.textContent = `
    @keyframes achievementPop {
        0% { transform: translate(-50%, -50%) scale(0); opacity: 0; }
        15% { transform: translate(-50%, -50%) scale(1.1); opacity: 1; }
        25% { transform: translate(-50%, -50%) scale(1); }
        90% { transform: translate(-50%, -50%) scale(1); opacity: 1; }
        100% { transform: translate(-50%, -50%) scale(0.9); opacity: 0; }
    }

    .achievement-notification .achievement-content {
        display: flex;
        align-items: center;
        gap: 1rem;
    }

    .achievement-notification .achievement-icon {
        font-size: 3rem;
        animation: bounce 1s ease-in-out infinite alternate;
    }

    .achievement-notification .achievement-text h4 {
        margin: 0 0 0.5rem 0;
        font-size: 1.2rem;
    }

    .achievement-notification .achievement-text p {
        margin: 0.25rem 0;
    }
`;
document.head.appendChild(achievementStyles);