from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from flask_cors import CORS
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
import json
from datetime import datetime, timedelta
import os

app = Flask(__name__)
app.secret_key = 'your-secret-key-change-this-in-production'
CORS(app)

# Database configuration
DATABASE = 'database/pathpilot.db'

def get_db_connection():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """Initialize database tables"""
    conn = get_db_connection()

    # Users table
    conn.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            full_name TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    # User progress table
    conn.execute('''
        CREATE TABLE IF NOT EXISTS user_progress (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            level_id INTEGER,
            xp INTEGER DEFAULT 0,
            status TEXT DEFAULT 'not_started',
            completion_date TIMESTAMP,
            data TEXT,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')

    # Achievements table
    conn.execute('''
        CREATE TABLE IF NOT EXISTS achievements (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            achievement_name TEXT,
            earned_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')

    conn.commit()
    conn.close()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/register', methods=['POST'])
def register():
    data = request.get_json()
    username = data.get('username')
    email = data.get('email')
    password = data.get('password')
    full_name = data.get('fullName')

    if not all([username, email, password, full_name]):
        return jsonify({'error': 'All fields are required'}), 400

    conn = get_db_connection()

    # Check if user already exists
    existing_user = conn.execute(
        'SELECT id FROM users WHERE username = ? OR email = ?',
        (username, email)
    ).fetchone()

    if existing_user:
        conn.close()
        return jsonify({'error': 'Username or email already exists'}), 400

    # Create new user
    password_hash = generate_password_hash(password)
    try:
        conn.execute(
            'INSERT INTO users (username, email, password_hash, full_name) VALUES (?, ?, ?, ?)',
            (username, email, password_hash, full_name)
        )
        conn.commit()

        # Get the new user
        user = conn.execute(
            'SELECT id, username, email, full_name FROM users WHERE username = ?',
            (username,)
        ).fetchone()

        conn.close()

        session['user_id'] = user['id']
        session['username'] = user['username']

        return jsonify({
            'success': True,
            'user': {
                'id': user['id'],
                'username': user['username'],
                'email': user['email'],
                'fullName': user['full_name']
            }
        })

    except Exception as e:
        conn.close()
        return jsonify({'error': 'Registration failed'}), 500

@app.route('/api/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')

    if not username or not password:
        return jsonify({'error': 'Username and password required'}), 400

    conn = get_db_connection()
    user = conn.execute(
        'SELECT * FROM users WHERE username = ?',
        (username,)
    ).fetchone()
    conn.close()

    if user and check_password_hash(user['password_hash'], password):
        session['user_id'] = user['id']
        session['username'] = user['username']

        return jsonify({
            'success': True,
            'user': {
                'id': user['id'],
                'username': user['username'],
                'email': user['email'],
                'fullName': user['full_name']
            }
        })
    else:
        return jsonify({'error': 'Invalid credentials'}), 401

@app.route('/api/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({'success': True})

@app.route('/api/progress', methods=['GET', 'POST'])
def handle_progress():
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401

    user_id = session['user_id']

    if request.method == 'GET':
        conn = get_db_connection()
        progress = conn.execute(
            'SELECT * FROM user_progress WHERE user_id = ?',
            (user_id,)
        ).fetchall()

        achievements = conn.execute(
            'SELECT * FROM achievements WHERE user_id = ?',
            (user_id,)
        ).fetchall()

        conn.close()

        return jsonify({
            'progress': [dict(row) for row in progress],
            'achievements': [dict(row) for row in achievements]
        })

    elif request.method == 'POST':
        data = request.get_json()
        level_id = data.get('level_id')
        xp = data.get('xp', 0)
        status = data.get('status', 'in_progress')
        progress_data = json.dumps(data.get('data', {}))

        conn = get_db_connection()

        # Update or insert progress
        existing = conn.execute(
            'SELECT id FROM user_progress WHERE user_id = ? AND level_id = ?',
            (user_id, level_id)
        ).fetchone()

        if existing:
            conn.execute(
                '''UPDATE user_progress 
                   SET xp = ?, status = ?, data = ?, completion_date = ?
                   WHERE user_id = ? AND level_id = ?''',
                (xp, status, progress_data, 
                 datetime.now() if status == 'completed' else None,
                 user_id, level_id)
            )
        else:
            conn.execute(
                '''INSERT INTO user_progress (user_id, level_id, xp, status, data, completion_date)
                   VALUES (?, ?, ?, ?, ?, ?)''',
                (user_id, level_id, xp, status, progress_data,
                 datetime.now() if status == 'completed' else None)
            )

        conn.commit()
        conn.close()

        return jsonify({'success': True})

@app.route('/api/certificate', methods=['POST'])
def generate_certificate():
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401

    user_id = session['user_id']

    # Check if user has completed all levels
    conn = get_db_connection()
    completed_levels = conn.execute(
        'SELECT COUNT(*) as count FROM user_progress WHERE user_id = ? AND status = "completed"',
        (user_id,)
    ).fetchone()

    user = conn.execute(
        'SELECT full_name FROM users WHERE id = ?',
        (user_id,)
    ).fetchone()

    conn.close()

    if completed_levels['count'] >= 5:  # All 5 levels completed
        certificate_data = {
            'user_name': user['full_name'],
            'completion_date': datetime.now().strftime('%B %d, %Y'),
            'certificate_id': f'PP-{user_id:04d}-{datetime.now().strftime("%Y%m%d")}',
            'founder_signature': 'Nitish.G'
        }
        return jsonify({'success': True, 'certificate': certificate_data})
    else:
        return jsonify({'error': 'Not all levels completed'}), 400

if __name__ == '__main__':
    # Create database directory if it doesn't exist
    os.makedirs('database', exist_ok=True)

    # Initialize database
    init_db()

    # Run the application
    app.run(debug=True, host='0.0.0.0', port=5000)
